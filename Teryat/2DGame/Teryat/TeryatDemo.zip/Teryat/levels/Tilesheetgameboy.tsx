<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="Tilegameboy" tilewidth="32" tileheight="32" tilecount="64" columns="2">
 <image source="../images/Tilesheetgameboy.png" width="64" height="1024"/>
</tileset>
